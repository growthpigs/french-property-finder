"use client"

import { useState } from "react"
import { PropertyCard } from "./PropertyCard"

// Sample property
const SAMPLE_PROPERTY = {
  id: 1,
  image: "https://images.unsplash.com/photo-1582407947304-fd86f028f716?q=80&w=2070&auto=format&fit=crop",
  location: "Avenue Victor Hugo • 16th",
  price: "€780,000",
  size: "85m²",
  rooms: "2 pieces",
  type: "Apt.",
}

export function TestPropertyCardActions() {
  const [property, setProperty] = useState(SAMPLE_PROPERTY)
  const [actionMessage, setActionMessage] = useState<string | null>(null)

  const handleRemove = (id: number) => {
    console.log(`Removing property ${id}`)
    setProperty(null)
  }

  const handleAction = (action: string, propertyId: number) => {
    const actionMessages = {
      info: "Showing property details...",
      call: "Calling agent...",
      share: "Sharing property...",
      web: "Opening website...",
    }

    setActionMessage(actionMessages[action as keyof typeof actionMessages] || `Action: ${action}`)

    // Clear message after 2 seconds
    setTimeout(() => {
      setActionMessage(null)
    }, 2000)
  }

  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold mb-4">Property Card Actions Test</h2>

      <div className="relative aspect-square w-full max-w-[300px] mx-auto">
        {property && (
          <PropertyCard property={property} index={0} total={1} onRemove={handleRemove} onAction={handleAction} />
        )}

        {!property && (
          <div className="flex items-center justify-center h-full bg-gray-100 rounded-lg">
            <p className="text-gray-500">Property removed</p>
          </div>
        )}
      </div>

      {actionMessage && (
        <div className="mt-4 p-2 bg-blue-100 text-blue-800 rounded-md text-center">{actionMessage}</div>
      )}
    </div>
  )
}

