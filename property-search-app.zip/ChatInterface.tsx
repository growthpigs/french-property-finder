"use client"

import type React from "react"

import { useRef, useEffect } from "react"
import { Send } from "lucide-react"
import { useAppState } from "./context/AppStateContext"
import { useConversation } from "./hooks"

export function ChatInterface() {
  // Get state and hooks
  const { state } = useAppState()
  const {
    messages,
    inputValue,
    setInputValue,
    showSuggestions,
    suggestionBubbles,
    handleSendMessage,
    handleSuggestion,
  } = useConversation()

  // Set up refs
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Focus the input field when component mounts
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus()
    }
  }, [])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value)
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage()
    }
  }

  return (
    <div className="flex-1 flex flex-col bg-white overflow-hidden">
      {/* Messages area - single scrollable conversation */}
      <div className="flex-1 p-4 overflow-y-auto">
        {/* Chat messages within conversation flow */}
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="mb-0">
              {message.isPropertyStack ? (
                <div className="property-results my-4">
                  <div className="text-center text-gray-500 mt-2">Swipe left to skip or right if you're interested</div>
                </div>
              ) : message.isSearching ? (
                <div className="flex items-center space-x-2 text-gray-500 italic">
                  <span>{message.text}</span>
                </div>
              ) : (
                <div className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`p-4 rounded-2xl max-w-[85%] text-[15px] leading-relaxed ${
                      message.sender === "user"
                        ? "bg-[#1E40AF] text-white rounded-tr-none"
                        : "bg-gray-200 text-gray-800 rounded-tl-none"
                    }`}
                  >
                    {message.text}
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Suggestion Bubbles */}
          {showSuggestions && (
            <div className="flex flex-wrap gap-2 my-4">
              {suggestionBubbles.map((suggestion) => (
                <button
                  key={suggestion.id}
                  className="bg-gray-100 text-gray-800 px-4 py-2 rounded-full text-sm hover:bg-gray-200 transition-colors"
                  onClick={() => handleSuggestion(suggestion.text)}
                >
                  {suggestion.text}
                </button>
              ))}
            </div>
          )}
        </div>

        <div ref={messagesEndRef} />
      </div>

      {/* Message input */}
      <div className="px-4 py-3 border-t border-gray-200 bg-gray-100">
        <div className="flex items-center h-12 px-4 bg-white rounded-full border border-gray-200 shadow-sm">
          <input
            ref={inputRef}
            type="text"
            placeholder="Message BKOK"
            className="flex-1 bg-transparent outline-none text-[15px]"
            value={inputValue}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
          />
          <button className="ml-2 text-gray-400">
            <Send size={20} className="transform rotate-45" />
          </button>
        </div>
      </div>
    </div>
  )
}

