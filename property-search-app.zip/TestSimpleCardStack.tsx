"use client"
import { SimpleCardStack } from "./SimpleCardStack"

export function TestSimpleCardStack() {
  return (
    <div className="p-4">
      <h2 className="text-lg font-bold mb-4">Simple Tinder Stack Test</h2>
      <SimpleCardStack />
    </div>
  )
}

