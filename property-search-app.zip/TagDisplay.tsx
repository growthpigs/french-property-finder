"use client"

import { X } from "lucide-react"
import type { Tag } from "./context/AppStateContext"

// Mapping for tag colors based on the screenshots
const tagColorMap: Record<string, string> = {
  buying: "bg-purple-400",
  "Paris, 16th": "bg-indigo-400",
  "€800k max": "bg-orange-400",
  "Apartment/Loft": "bg-blue-400",
  Balcony: "bg-sky-400",
  "2 pieces": "bg-green-400",

  // Default colors by category
  location: "bg-indigo-400",
  price: "bg-orange-400",
  "property-type": "bg-blue-400",
  feature: "bg-sky-400",
  rooms: "bg-green-400",
  status: "bg-purple-400",
}

interface TagDisplayProps {
  tags: Tag[]
  onRemove: (id: string) => void
}

export function TagDisplay({ tags, onRemove }: TagDisplayProps) {
  // Safely handle potentially undefined tags
  const safeTagsArray = Array.isArray(tags) ? tags : []

  // Always render the component even with no tags, to maintain fixed position
  return (
    <div className="px-4 min-h-8 flex items-center flex-wrap gap-2 bg-white pt-2 pb-2 border-t border-gray-200 sticky bottom-16 z-10">
      {safeTagsArray.map((tag) => {
        // Determine color based on tag label or fallback to the one from state
        const colorClass = tagColorMap[tag.label] || tag.color || "bg-gray-400"

        return (
          <div
            key={tag.id}
            className={`flex items-center rounded-full px-3 py-1 text-sm ${colorClass} text-white shadow-sm`}
          >
            {tag.label}
            <button onClick={() => onRemove(tag.id)} className="ml-1 flex items-center justify-center">
              <X size={14} />
            </button>
          </div>
        )
      })}
    </div>
  )
}

