"use client"
import { SimpleStack } from "./SimpleStack"

export function TestSimpleStack() {
  return (
    <div className="p-4">
      <h2 className="text-lg font-semibold mb-4">Simple Card Stack Test</h2>
      <SimpleStack />
    </div>
  )
}

