"use client"

import { AppStateProvider } from "./context/AppStateContext"
import { ChatInterface } from "./ChatInterface"
import { useAppState } from "./context/AppStateContext"
import { TagDisplay } from "./TagDisplay"
import { useTagManagement } from "./hooks"

const StatusBar = () => {
  return (
    <div className="h-8 px-6 flex items-center justify-between bg-black text-white text-xs">
      <span>9:41 AM</span>
      <div className="flex items-center space-x-2">
        <div className="w-4 h-4 rounded-full border-2 border-white"></div>
        <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor">
          <path d="M8.5,0.5 C11,0.5 13.5,2 13.5,5.5 C13.5,9 11,10.5 8.5,10.5 C6,10.5 3.5,9 3.5,5.5 C3.5,2 6,0.5 8.5,0.5 Z"></path>
        </svg>
        <svg width="18" height="14" viewBox="0 0 18 14" fill="currentColor">
          <path d="M1,4 L1,10 L3,10 L6,13 L6,1 L3,4 L1,4 Z M10,1 C12.761,1 15,3.239 15,6 C15,8.761 12.761,11 10,11 L10,13 C13.866,13 17,10.134 17,6 C17,1.866 13.866,-1 10,-1 L10,1 Z M10,3 C11.654,3 13,4.346 13,6 C13,7.654 11.654,9 10,9 L10,11 C12.761,11 15,8.761 15,6 C15,3.239 12.761,1 10,1 L10,3 Z"></path>
        </svg>
        <div className="flex items-center space-x-0.5">
          <div className="h-3.5 w-0.5 bg-white rounded-sm"></div>
          <div className="h-4 w-0.5 bg-white rounded-sm"></div>
          <div className="h-2.5 w-0.5 bg-white rounded-sm"></div>
          <div className="h-3 w-0.5 bg-white rounded-sm"></div>
          <div className="h-3.5 w-0.5 bg-white rounded-sm"></div>
        </div>
      </div>
    </div>
  )
}

const HeaderComponent = () => {
  return (
    <div className="h-14 px-4 flex items-center justify-between border-b border-gray-100 bg-white">
      <button className="p-2">
        <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
          <line x1="3" y1="12" x2="21" y2="12"></line>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>
      </button>
      <div className="text-base font-medium text-[#2563EB]">My Renter Profile &gt;</div>
      <button className="p-2">
        <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" strokeWidth="2" fill="none">
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
        </svg>
      </button>
    </div>
  )
}

const BottomNavigation = () => {
  return (
    <div className="h-16 border-t border-gray-200 grid grid-cols-5 bg-white">
      <button className="flex flex-col items-center justify-center text-[#2563EB] font-medium">
        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" fill="none" className="mb-1">
          <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
          <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
          <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
        </svg>
        <span className="text-xs">Recherche</span>
      </button>
      <button className="flex flex-col items-center justify-center text-gray-500">
        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" fill="none" className="mb-1">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
          <polyline points="22 4 12 14.01 9 11.01"></polyline>
        </svg>
        <span className="text-xs">Explorer</span>
      </button>
      <button className="flex flex-col items-center justify-center text-gray-500">
        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" fill="none" className="mb-1">
          <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
          <polyline points="22,6 12,13 2,6"></polyline>
        </svg>
        <span className="text-xs">Mes Biens</span>
      </button>
      <button className="flex flex-col items-center justify-center text-gray-500">
        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" fill="none" className="mb-1">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
        </svg>
        <span className="text-xs">Notifs</span>
      </button>
      <button className="flex flex-col items-center justify-center text-gray-500">
        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" fill="none" className="mb-1">
          <circle cx="12" cy="12" r="3"></circle>
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
        </svg>
        <span className="text-xs">Réglages</span>
      </button>
    </div>
  )
}

const AppContent = () => {
  const { state } = useAppState()
  const { tags, removeTag } = useTagManagement()

  return (
    <div className="relative flex flex-col w-full h-full overflow-hidden bg-white">
      {/* Status Bar */}
      <StatusBar />

      {/* App Header */}
      <HeaderComponent />

      {/* Main Content Area */}
      <ChatInterface />

      {/* Tags Display */}
      <TagDisplay tags={tags} onRemove={removeTag} />

      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  )
}

// Main component that provides the context
export function PropertyApp() {
  return (
    <AppStateProvider>
      <div className="w-full h-screen md:max-w-md md:h-[800px] border border-gray-200 rounded-xl overflow-hidden shadow-xl">
        <AppContent />
      </div>
    </AppStateProvider>
  )
}

