"use client"

import { PropertyApp } from "../PropertyApp"

export default function SyntheticV0PageForDeployment() {
  return <PropertyApp />
}